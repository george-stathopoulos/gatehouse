=== Gatehouse Pro ===
Requires at least: 7.0
Tested up to: 7.1
Requires PHP: 7.4
Requires Plugins: gatehouse
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Response caching for Gatehouse: repeated AI requests are answered instantly from a cache, at no cost.

== Description ==

Gatehouse Pro adds response caching to the free Gatehouse plugin. When a plugin sends exactly the same AI request again (the same spam check, the same FAQ answer, the same alt-text request), Pro answers it from a cache instead of paying the AI provider again.

* Choose which plugins are cached, with recommendations based on how often each one repeats itself.
* Answers are kept for 1 hour, 24 hours, 7 days or 30 days.
* Cached answers never contain personal data removed by Gatehouse's redaction; it is restored per request.
* Savings appear on the Gatehouse Overview, the Caching page and in the request log.

== Installation ==

1. Install and activate the free Gatehouse plugin.
2. Upload gatehouse-pro.zip under Plugins → Add New → Upload Plugin, and activate it.
3. Go to Gatehouse → Caching, enter your license key and click Activate.
4. Turn on caching for the recommended plugins.

== Changelog ==

= 1.0.0 =
* First release: response caching, license activation, automatic updates.
