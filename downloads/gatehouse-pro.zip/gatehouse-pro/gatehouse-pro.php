<?php
/**
 * Plugin Name:       Gatehouse Pro
 * Plugin URI:        https://george-stathopoulos.github.io/gatehouse/pro/
 * Description:       Response caching for Gatehouse: repeated AI requests are answered instantly from a cache, at no cost.
 * Version:           1.0.0
 * Requires at least: 7.0
 * Requires PHP:      7.4
 * Requires Plugins:  gatehouse
 * Author:            George Stathopoulos
 * Author URI:        https://george-stathopoulos.github.io/gatehouse/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       gatehouse-pro
 *
 * @package Gatehouse_Pro
 */

defined( 'ABSPATH' ) || exit;

define( 'GATEHOUSE_PRO_VERSION', '1.0.0' );
define( 'GATEHOUSE_PRO_FILE', __FILE__ );
define( 'GATEHOUSE_PRO_DIR', plugin_dir_path( __FILE__ ) );
define( 'GATEHOUSE_PRO_URL', plugin_dir_url( __FILE__ ) );

/*
 * Store configuration. Set these to your Lemon Squeezy store before building a release.
 *
 * - GATEHOUSE_PRO_STORE_ID / GATEHOUSE_PRO_PRODUCT_ID: license keys from any other store or product are rejected.
 *   Leave GATEHOUSE_PRO_PRODUCT_ID at 0 to accept every product in the store.
 * - GATEHOUSE_PRO_BUY_URL: where the "Buy a license" button points.
 * - GATEHOUSE_PRO_UPDATE_URL: JSON update manifest (see includes/class-updater.php). Empty disables updates.
 */
defined( 'GATEHOUSE_PRO_STORE_ID' ) || define( 'GATEHOUSE_PRO_STORE_ID', 0 );
defined( 'GATEHOUSE_PRO_PRODUCT_ID' ) || define( 'GATEHOUSE_PRO_PRODUCT_ID', 0 );
defined( 'GATEHOUSE_PRO_BUY_URL' ) || define( 'GATEHOUSE_PRO_BUY_URL', '' );
defined( 'GATEHOUSE_PRO_UPDATE_URL' ) || define( 'GATEHOUSE_PRO_UPDATE_URL', '' );

require_once GATEHOUSE_PRO_DIR . 'includes/class-license.php';
require_once GATEHOUSE_PRO_DIR . 'includes/class-cache.php';
require_once GATEHOUSE_PRO_DIR . 'includes/class-rest.php';
require_once GATEHOUSE_PRO_DIR . 'includes/class-updater.php';
require_once GATEHOUSE_PRO_DIR . 'includes/class-plugin.php';

register_activation_hook( __FILE__, array( 'Gatehouse_Pro_Plugin', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'Gatehouse_Pro_Plugin', 'deactivate' ) );

add_action( 'plugins_loaded', array( 'Gatehouse_Pro_Plugin', 'boot' ), 20 );
