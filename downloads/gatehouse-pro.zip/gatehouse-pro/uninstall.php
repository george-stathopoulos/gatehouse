<?php
/**
 * Uninstall: remove the cache table, settings and license.
 *
 * The license activation is released locally only. Customers can free the activation slot from
 * the "Deactivate" button before uninstalling, or from their store account.
 *
 * @package Gatehouse_Pro
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

global $wpdb;
$gatehouse_pro_table = $wpdb->prefix . 'gatehouse_pro_cache';
$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', $gatehouse_pro_table ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange

foreach ( array( 'gatehouse_pro_settings', 'gatehouse_pro_license', 'gatehouse_pro_db_version' ) as $gatehouse_pro_option ) {
	delete_option( $gatehouse_pro_option );
}
delete_transient( 'gatehouse_pro_update_manifest' );
wp_clear_scheduled_hook( 'gatehouse_pro_cache_prune' );
wp_clear_scheduled_hook( 'gatehouse_pro_license_check' );
