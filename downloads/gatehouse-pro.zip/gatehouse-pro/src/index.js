import { __ } from '@wordpress/i18n';
import { addFilter } from '@wordpress/hooks';
import Caching from './Caching';

/**
 * Adds the Caching page to Gatehouse, before Settings.
 */
addFilter( 'gatehouse.routes', 'gatehouse-pro/caching', ( routes ) => {
	const next = [ ...routes ];
	const at = next.findIndex( ( r ) => r.id === 'settings' );
	next.splice( at < 0 ? next.length : at, 0, {
		id: 'caching',
		label: __( 'Caching', 'gatehouse-pro' ),
		icon: 'bolt',
		Page: Caching,
	} );
	return next;
} );
