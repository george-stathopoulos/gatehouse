import { __, _n, sprintf } from '@wordpress/i18n';
import apiFetch from '@wordpress/api-fetch';
import { useCallback, useEffect, useMemo, useState } from '@wordpress/element';

const { ui, Icon, format, colors, settings: shared } = window.gatehouse;
const {
	Card,
	PageHead,
	Pill,
	Button,
	Switch,
	Setting,
	Segmented,
	Loading,
	ErrorNotice,
	SourceAvatar,
	useToast,
	typeLabel,
} = ui;
const { money, integer } = format;

const API = '/gatehouse-pro/v1/';

const TTL = [
	{ value: 1, label: __( '1 hour', 'gatehouse-pro' ) },
	{ value: 24, label: __( '24 hours', 'gatehouse-pro' ) },
	{ value: 168, label: __( '7 days', 'gatehouse-pro' ) },
	{ value: 720, label: __( '30 days', 'gatehouse-pro' ) },
];

const SIZES = [ 25, 50, 100, 250 ];

/**
 * Load Pro status.
 *
 * @return {Object} { data, error, reload }.
 */
function useStatus() {
	const [ data, setData ] = useState( null );
	const [ error, setError ] = useState( null );
	const reload = useCallback( () => {
		apiFetch( { path: `${ API }status` } )
			.then( ( d ) => {
				setData( d );
				setError( null );
			} )
			.catch( setError );
	}, [] );
	useEffect( reload, [ reload ] );
	return { data, error, reload, setData };
}

export default function Caching() {
	const { data, error, reload } = useStatus();
	const [ draft, setDraft ] = useState( null );
	const [ saving, setSaving ] = useState( false );
	const toast = useToast();
	const colorOf = useMemo(
		() => colors.makeColorer( data?.order ),
		[ data?.order ]
	);

	useEffect( () => {
		if ( data ) {
			setDraft( data.settings );
		}
	}, [ data ] );

	if ( error && ! data ) {
		return <ErrorNotice error={ error } onRetry={ reload } />;
	}
	if ( ! data || ! draft ) {
		return <Loading />;
	}

	const licensed = data.license.active;
	const dirty = JSON.stringify( draft ) !== JSON.stringify( data.settings );
	const set = ( key ) => ( value ) =>
		setDraft( ( d ) => ( { ...d, [ key ]: value } ) );
	const selected = new Set( draft.sources );
	const toggleSource = ( id, on ) =>
		set( 'sources' )(
			on
				? [ ...draft.sources, id ]
				: draft.sources.filter( ( s ) => s !== id )
		);

	const save = () => {
		setSaving( true );
		apiFetch( { path: `${ API }settings`, method: 'POST', data: draft } )
			.then( () => {
				toast( __( 'Caching settings saved', 'gatehouse-pro' ) );
				reload();
			} )
			.catch( ( e ) => toast( e.message, 'alert' ) )
			.finally( () => setSaving( false ) );
	};

	return (
		<div>
			<PageHead
				title={ __( 'Caching', 'gatehouse-pro' ) }
				lede={ __(
					'When a plugin sends exactly the same AI request again, Gatehouse Pro answers it instantly from a cache instead of paying the provider again.',
					'gatehouse-pro'
				) }
			>
				<Pill tone="accent" icon="bolt">
					{ __( 'Pro', 'gatehouse-pro' ) }
				</Pill>
				{ licensed && draft.enabled && (
					<Pill tone="good" icon="check">
						{ __( 'Caching on', 'gatehouse-pro' ) }
					</Pill>
				) }
			</PageHead>

			{ ! licensed && (
				<LicenseCard data={ data } onChange={ reload } prominent />
			) }

			<div
				style={ {
					opacity: licensed ? 1 : 0.55,
					pointerEvents: licensed ? 'auto' : 'none',
				} }
				aria-disabled={ ! licensed }
			>
				<Stats data={ data } />

				<div className="gatehouse-grid">
					<Card
						className="gatehouse-span-5"
						title={ __( 'Cache settings', 'gatehouse-pro' ) }
						bodyClass={ null }
					>
						<div style={ { marginTop: 8 } }>
							<Setting
								title={ __(
									'Cache responses',
									'gatehouse-pro'
								) }
								desc={ __(
									'Answer repeated requests from the sources you choose.',
									'gatehouse-pro'
								) }
							>
								<Switch
									checked={ draft.enabled }
									onChange={ set( 'enabled' ) }
									label={ __(
										'Cache responses',
										'gatehouse-pro'
									) }
								/>
							</Setting>
							<Setting
								title={ __(
									'Keep answers for',
									'gatehouse-pro'
								) }
								desc={ __(
									'After this, the next identical request goes to the provider again and refreshes the cache.',
									'gatehouse-pro'
								) }
							/>
							<div style={ { padding: '0 20px 16px' } }>
								<Segmented
									label={ __(
										'Cache lifetime',
										'gatehouse-pro'
									) }
									options={ TTL }
									value={ draft.ttl_hours }
									onChange={ set( 'ttl_hours' ) }
								/>
							</div>
							<Setting
								title={ __( 'Which sources', 'gatehouse-pro' ) }
								desc={ __(
									'“Selected” is safest: some plugins expect a fresh answer every time.',
									'gatehouse-pro'
								) }
							/>
							<div style={ { padding: '0 20px 16px' } }>
								<Segmented
									label={ __(
										'Sources to cache',
										'gatehouse-pro'
									) }
									options={ [
										{
											value: 'selected',
											label: __(
												'Selected sources',
												'gatehouse-pro'
											),
										},
										{
											value: 'all',
											label: __(
												'All sources',
												'gatehouse-pro'
											),
										},
									] }
									value={ draft.mode }
									onChange={ set( 'mode' ) }
								/>
							</div>
							<Setting
								title={ __(
									'Maximum cache size',
									'gatehouse-pro'
								) }
								desc={ __(
									'The least recently used answers are removed first.',
									'gatehouse-pro'
								) }
							>
								<select
									className="gatehouse-select"
									style={ { width: 110 } }
									value={ draft.max_mb }
									aria-label={ __(
										'Maximum cache size',
										'gatehouse-pro'
									) }
									onChange={ ( e ) =>
										set( 'max_mb' )(
											Number( e.target.value )
										)
									}
								>
									{ SIZES.map( ( mb ) => (
										<option key={ mb } value={ mb }>
											{ `${ mb } MB` }
										</option>
									) ) }
								</select>
							</Setting>
						</div>
					</Card>

					<Card
						className="gatehouse-span-7"
						title={ __( 'Sources', 'gatehouse-pro' ) }
						sub={ __(
							'Sorted by what caching could save, based on repeated requests in the last 30 days.',
							'gatehouse-pro'
						) }
						bodyClass={ null }
					>
						<Sources
							sources={ data.sources }
							selected={ selected }
							all={ draft.mode === 'all' }
							onToggle={ toggleSource }
							colorOf={ colorOf }
						/>
						<p
							className="gatehouse-muted gatehouse-row"
							style={ {
								fontSize: 12.5,
								padding: '12px 20px 16px',
								gap: 8,
								flexWrap: 'nowrap',
								alignItems: 'flex-start',
							} }
						>
							<Icon
								name="info"
								size={ 15 }
								style={ { flexShrink: 0, marginTop: 1 } }
							/>
							{ __(
								'Don’t cache plugins that should give a different answer each time, such as content generators with a “regenerate” button. Good candidates are spam checks, classification, alt text and FAQ-style answers.',
								'gatehouse-pro'
							) }
						</p>
					</Card>
				</div>

				<Maintenance data={ data } onChange={ reload } />
			</div>

			{ licensed && <LicenseCard data={ data } onChange={ reload } /> }

			<shared.SaveBar
				dirty={ dirty }
				saving={ saving }
				save={ save }
				discard={ () => setDraft( data.settings ) }
			/>
		</div>
	);
}

function Stats( { data } ) {
	const { cache, repeats } = data;
	const tiles = [
		{
			icon: 'coins',
			label: __( 'Saved, last 30 days', 'gatehouse-pro' ),
			value: money( cache.saved ),
			foot:
				repeats.potential > 0
					? sprintf(
							/* translators: %s: amount. */
							__(
								'%s more possible from uncached repeats',
								'gatehouse-pro'
							),
							money( repeats.potential )
					  )
					: __( 'No uncached repeats', 'gatehouse-pro' ),
		},
		{
			icon: 'bolt',
			label: __( 'Answered from cache', 'gatehouse-pro' ),
			value: integer( cache.cached ),
			foot: sprintf(
				/* translators: %s: percent. */
				__( '%s%% of completed calls', 'gatehouse-pro' ),
				Math.round( cache.hit_rate * 1000 ) / 10
			),
		},
		{
			icon: 'tokens',
			label: __( 'Cached answers', 'gatehouse-pro' ),
			value: integer( cache.entries ),
			foot: sprintf(
				/* translators: %s: size in MB. */
				__( '%s MB in use', 'gatehouse-pro' ),
				( cache.bytes / 1048576 ).toFixed( 1 )
			),
		},
	];
	return (
		<div className="gatehouse-stats-strip">
			{ tiles.map( ( t ) => (
				<Card key={ t.label } bodyClass={ null }>
					<div className="gatehouse-stat">
						<div className="gatehouse-stat__label">
							<Icon name={ t.icon } size={ 14 } />
							{ t.label }
						</div>
						<div className="gatehouse-stat__value">{ t.value }</div>
						<div
							className="gatehouse-muted"
							style={ { fontSize: 12.5 } }
						>
							{ t.foot }
						</div>
					</div>
				</Card>
			) ) }
		</div>
	);
}

function Sources( { sources, selected, all, onToggle, colorOf } ) {
	if ( ! sources.length ) {
		return (
			<div className="gatehouse-card__body gatehouse-muted">
				{ __(
					'Sources appear here after their first AI call.',
					'gatehouse-pro'
				) }
			</div>
		);
	}
	const best = sources[ 0 ]?.potential > 0 ? sources[ 0 ].id : null;
	return (
		<div style={ { marginTop: 8 } }>
			{ sources.map( ( s ) => (
				<Setting
					key={ s.id }
					title={
						<span className="gatehouse-source">
							<SourceAvatar
								label={ s.label }
								color={ colorOf( s.id ) }
							/>
							<span>{ s.label }</span>
						</span>
					}
					badge={
						s.id === best && ! selected.has( s.id ) && ! all ? (
							<Pill tone="accent" icon="spark">
								{ __( 'Recommended', 'gatehouse-pro' ) }
							</Pill>
						) : (
							<span
								className="gatehouse-muted"
								style={ { fontWeight: 450, fontSize: 12.5 } }
							>
								{ typeLabel( s.type ) }
							</span>
						)
					}
					desc={
						s.repeats > 0
							? sprintf(
									/* translators: 1: number of repeated calls, 2: percent, 3: amount. */
									_n(
										'%1$s repeated call (%2$s%%) · could save %3$s',
										'%1$s repeated calls (%2$s%%) · could save %3$s',
										s.repeats,
										'gatehouse-pro'
									),
									integer( s.repeats ),
									Math.round( s.share * 100 ),
									money( s.potential )
							  )
							: __(
									'No repeated requests in the last 30 days',
									'gatehouse-pro'
							  )
					}
				>
					<Switch
						checked={ all || selected.has( s.id ) }
						disabled={ all }
						onChange={ ( on ) => onToggle( s.id, on ) }
						label={ sprintf(
							/* translators: %s: source name. */
							__( 'Cache responses for %s', 'gatehouse-pro' ),
							s.label
						) }
					/>
				</Setting>
			) ) }
		</div>
	);
}

function Maintenance( { data, onChange } ) {
	const [ armed, setArmed ] = useState( false );
	const toast = useToast();
	const clear = () => {
		if ( ! armed ) {
			setArmed( true );
			window.setTimeout( () => setArmed( false ), 4000 );
			return;
		}
		apiFetch( { path: `${ API }cache`, method: 'DELETE' } )
			.then( () => {
				toast( __( 'Cache cleared', 'gatehouse-pro' ) );
				onChange();
			} )
			.catch( ( e ) => toast( e.message, 'alert' ) )
			.finally( () => setArmed( false ) );
	};
	return (
		<Card bodyClass={ null } style={ { marginBottom: 18 } }>
			<Setting
				title={ __( 'Clear cache', 'gatehouse-pro' ) }
				desc={ sprintf(
					/* translators: %s: number of entries. */
					__(
						'Deletes all %s cached answers. Use it after changing a plugin’s settings or content that its answers depend on. Cached answers never contain redacted personal data.',
						'gatehouse-pro'
					),
					integer( data.cache.entries )
				) }
			>
				<Button variant="danger" icon="trash" onClick={ clear }>
					{ armed
						? __( 'Click again to confirm', 'gatehouse-pro' )
						: __( 'Clear cache', 'gatehouse-pro' ) }
				</Button>
			</Setting>
		</Card>
	);
}

function LicenseCard( { data, onChange, prominent = false } ) {
	const { license } = data;
	const [ key, setKey ] = useState( '' );
	const [ busy, setBusy ] = useState( false );
	const [ message, setMessage ] = useState( '' );
	const toast = useToast();

	const call = ( path, method, body, done ) => {
		setBusy( true );
		setMessage( '' );
		apiFetch( { path: `${ API }${ path }`, method, data: body } )
			.then( () => {
				done();
				onChange();
			} )
			.catch( ( e ) => setMessage( e.message ) )
			.finally( () => setBusy( false ) );
	};

	const activate = ( e ) => {
		e.preventDefault();
		call( 'license', 'POST', { key }, () => {
			setKey( '' );
			toast(
				__( 'License activated. Pro features are on.', 'gatehouse-pro' )
			);
		} );
	};

	const statusPill = () => {
		if ( license.active && license.grace ) {
			return (
				<Pill tone="warning" icon="alert">
					{ __( 'Active (offline check)', 'gatehouse-pro' ) }
				</Pill>
			);
		}
		if ( license.active ) {
			return (
				<Pill tone="good" icon="check">
					{ __( 'Active', 'gatehouse-pro' ) }
				</Pill>
			);
		}
		if ( license.status === 'expired' ) {
			return (
				<Pill tone="critical" icon="clock">
					{ __( 'Expired', 'gatehouse-pro' ) }
				</Pill>
			);
		}
		return (
			<Pill icon="ban">{ __( 'Not activated', 'gatehouse-pro' ) }</Pill>
		);
	};

	return (
		<Card
			title={ __( 'License', 'gatehouse-pro' ) }
			sub={
				prominent
					? __(
							'Activate your license to turn on caching. Until then you can explore this page with your own data.',
							'gatehouse-pro'
					  )
					: null
			}
			action={ statusPill() }
			style={ { marginBottom: 18 } }
		>
			{ license.active ? (
				<div
					className="gatehouse-row"
					style={ { justifyContent: 'space-between' } }
				>
					<dl className="gatehouse-dl" style={ { flex: 1 } }>
						<dt>{ __( 'Product', 'gatehouse-pro' ) }</dt>
						<dd>{ license.product || 'Gatehouse Pro' }</dd>
						<dt>{ __( 'License key', 'gatehouse-pro' ) }</dt>
						<dd>
							<code>{ license.key }</code>
						</dd>
						<dt>{ __( 'Renews or expires', 'gatehouse-pro' ) }</dt>
						<dd>
							{ license.expires_at
								? format.dateLong(
										license.expires_at.slice( 0, 10 )
								  )
								: __( 'Never', 'gatehouse-pro' ) }
						</dd>
						{ license.error && (
							<>
								<dt>{ __( 'Last check', 'gatehouse-pro' ) }</dt>
								<dd>{ license.error }</dd>
							</>
						) }
					</dl>
					<div className="gatehouse-row" style={ { gap: 8 } }>
						<Button
							size="sm"
							icon="refresh"
							disabled={ busy }
							onClick={ () =>
								call( 'license/check', 'POST', {}, () =>
									toast(
										__( 'License checked', 'gatehouse-pro' )
									)
								)
							}
						>
							{ __( 'Check now', 'gatehouse-pro' ) }
						</Button>
						<Button
							size="sm"
							variant="danger"
							disabled={ busy }
							onClick={ () =>
								call( 'license', 'DELETE', {}, () =>
									toast(
										__(
											'License deactivated on this site',
											'gatehouse-pro'
										)
									)
								)
							}
						>
							{ __( 'Deactivate', 'gatehouse-pro' ) }
						</Button>
					</div>
				</div>
			) : (
				<form onSubmit={ activate }>
					{ ! license.store_configured && (
						<p
							className="gatehouse-muted"
							style={ { marginBottom: 12, fontSize: 13 } }
						>
							{ __(
								'This copy of Gatehouse Pro is not connected to a store yet, so license keys cannot be activated.',
								'gatehouse-pro'
							) }
						</p>
					) }
					{ license.status === 'expired' && license.error && (
						<p style={ { marginBottom: 12, fontSize: 13 } }>
							{ license.error }
						</p>
					) }
					<div
						className="gatehouse-row"
						style={ { gap: 10, flexWrap: 'nowrap' } }
					>
						<input
							className="gatehouse-input"
							style={ { maxWidth: 420 } }
							value={ key }
							placeholder="XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX"
							aria-label={ __( 'License key', 'gatehouse-pro' ) }
							onChange={ ( e ) => setKey( e.target.value ) }
						/>
						<Button
							variant="primary"
							type="submit"
							disabled={
								busy ||
								! key.trim() ||
								! license.store_configured
							}
						>
							{ busy
								? __( 'Activating…', 'gatehouse-pro' )
								: __( 'Activate', 'gatehouse-pro' ) }
						</Button>
						{ data.buy_url && (
							<a
								className="gatehouse-btn"
								href={ data.buy_url }
								target="_blank"
								rel="noopener noreferrer"
							>
								{ __( 'Buy a license', 'gatehouse-pro' ) }
								<Icon name="external" size={ 13 } />
							</a>
						) }
					</div>
					{ message && (
						<p
							role="alert"
							style={ {
								color: 'var(--gatehouse-critical-ink)',
								marginTop: 10,
								fontSize: 13,
							} }
						>
							{ message }
						</p>
					) }
				</form>
			) }
		</Card>
	);
}
