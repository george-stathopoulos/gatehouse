<?php
/**
 * REST API for the Pro dashboard page.
 *
 * @package Gatehouse_Pro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Routes under `gatehouse-pro/v1`. Every route requires `manage_options`.
 */
final class Gatehouse_Pro_REST {

	const NS = 'gatehouse-pro/v1';

	/**
	 * Register routes.
	 */
	public static function register() {
		$admin = static function () {
			return current_user_can( 'manage_options' );
		};

		register_rest_route(
			self::NS,
			'/status',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'status' ),
				'permission_callback' => $admin,
			)
		);
		register_rest_route(
			self::NS,
			'/license',
			array(
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( __CLASS__, 'activate' ),
					'permission_callback' => $admin,
					'args'                => array(
						'key' => array(
							'type'     => 'string',
							'required' => true,
						),
					),
				),
				array(
					'methods'             => WP_REST_Server::DELETABLE,
					'callback'            => array( __CLASS__, 'deactivate' ),
					'permission_callback' => $admin,
				),
			)
		);
		register_rest_route(
			self::NS,
			'/license/check',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'check' ),
				'permission_callback' => $admin,
			)
		);
		register_rest_route(
			self::NS,
			'/settings',
			array(
				'methods'             => WP_REST_Server::EDITABLE,
				'callback'            => array( __CLASS__, 'settings' ),
				'permission_callback' => $admin,
			)
		);
		register_rest_route(
			self::NS,
			'/cache',
			array(
				'methods'             => WP_REST_Server::DELETABLE,
				'callback'            => array( __CLASS__, 'clear' ),
				'permission_callback' => $admin,
			)
		);
	}

	/**
	 * GET /status: license, settings, cache statistics and per-source recommendations.
	 *
	 * @return WP_REST_Response
	 */
	public static function status() {
		$now      = current_time( 'timestamp' ); // phpcs:ignore WordPress.DateTime.CurrentTimeTimestamp.Requested
		$from     = $now - 30 * DAY_IN_SECONDS;
		$repeats  = Gatehouse_Stats::repeats( $from, $now + 1 );
		$by_id    = array();
		foreach ( $repeats['sources'] as $r ) {
			$by_id[ $r['id'] ] = $r;
		}
		$sources = array();
		foreach ( Gatehouse_Stats::sources( $from, $now + 1 ) as $s ) {
			$sources[] = array(
				'id'        => $s['id'],
				'label'     => $s['label'],
				'type'      => $s['type'],
				'requests'  => $s['requests'],
				'repeats'   => $by_id[ $s['id'] ]['calls'] ?? 0,
				'share'     => $by_id[ $s['id'] ]['share'] ?? 0,
				'potential' => $by_id[ $s['id'] ]['potential'] ?? 0,
			);
		}
		usort(
			$sources,
			static function ( $a, $b ) {
				return $b['potential'] <=> $a['potential'] ?: $b['requests'] <=> $a['requests'];
			}
		);

		return rest_ensure_response(
			array(
				'license'  => Gatehouse_Pro_License::public_state(),
				'settings' => Gatehouse_Pro_Cache::settings(),
				'cache'    => Gatehouse_Pro_Cache::stats(),
				'repeats'  => array(
					'calls'     => $repeats['calls'],
					'potential' => $repeats['potential'],
				),
				'sources'  => $sources,
				'order'    => Gatehouse_Stats::source_order(),
				'buy_url'  => esc_url_raw( (string) GATEHOUSE_PRO_BUY_URL ),
				'version'  => GATEHOUSE_PRO_VERSION,
			)
		);
	}

	/**
	 * POST /license: activate a key.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function activate( WP_REST_Request $request ) {
		$result = Gatehouse_Pro_License::activate( (string) $request['key'] );
		if ( is_wp_error( $result ) ) {
			$result->add_data( array( 'status' => 400 ) );
			return $result;
		}
		return rest_ensure_response( Gatehouse_Pro_License::public_state() );
	}

	/**
	 * DELETE /license: deactivate on this site.
	 *
	 * @return WP_REST_Response
	 */
	public static function deactivate() {
		Gatehouse_Pro_License::deactivate();
		return rest_ensure_response( Gatehouse_Pro_License::public_state() );
	}

	/**
	 * POST /license/check: re-validate now.
	 *
	 * @return WP_REST_Response
	 */
	public static function check() {
		Gatehouse_Pro_License::check();
		return rest_ensure_response( Gatehouse_Pro_License::public_state() );
	}

	/**
	 * POST /settings.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function settings( WP_REST_Request $request ) {
		$input = $request->get_json_params();
		return rest_ensure_response( Gatehouse_Pro_Cache::update_settings( is_array( $input ) ? $input : array() ) );
	}

	/**
	 * DELETE /cache.
	 *
	 * @return WP_REST_Response
	 */
	public static function clear() {
		Gatehouse_Pro_Cache::clear();
		return rest_ensure_response( Gatehouse_Pro_Cache::stats() );
	}
}
