<?php
/**
 * License keys (Lemon Squeezy License API).
 *
 * @package Gatehouse_Pro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Activates, checks and deactivates this site's license.
 *
 * Uses Lemon Squeezy's public License API, which needs no secret keys in the plugin. Every response
 * is checked against GATEHOUSE_PRO_STORE_ID / GATEHOUSE_PRO_PRODUCT_ID, because the API accepts keys from any store.
 * If the licensing server cannot be reached, a previously valid license keeps working for
 * GRACE_DAYS so an outage never switches a customer's features off.
 */
final class Gatehouse_Pro_License {

	const OPTION     = 'gatehouse_pro_license';
	const API        = 'https://api.lemonsqueezy.com/v1/licenses/';
	const GRACE_DAYS = 14;
	const CRON       = 'gatehouse_pro_license_check';

	/**
	 * Stored license state merged over defaults.
	 *
	 * @return array
	 */
	public static function state() {
		$stored = get_option( self::OPTION, array() );
		return array_merge(
			array(
				'key'           => '',
				'instance_id'   => '',
				'status'        => 'inactive',
				'product'       => '',
				'expires_at'    => null,
				'checked_at'    => 0,
				'last_valid_at' => 0,
				'error'         => '',
			),
			is_array( $stored ) ? $stored : array()
		);
	}

	/**
	 * Whether Pro features are unlocked.
	 *
	 * @return bool
	 */
	public static function is_active() {
		$state  = self::state();
		$active = 'active' === $state['status'] && ( time() - (int) $state['last_valid_at'] ) <= self::GRACE_DAYS * DAY_IN_SECONDS;

		/**
		 * Filters whether the Pro license is active.
		 *
		 * @param bool  $active Active.
		 * @param array $state  License state.
		 */
		return (bool) apply_filters( 'gatehouse_pro_license_active', $active, $state );
	}

	/**
	 * Whether this build has a store configured.
	 *
	 * @return bool
	 */
	public static function store_configured() {
		return (int) GATEHOUSE_PRO_STORE_ID > 0;
	}

	/**
	 * Activate a key for this site.
	 *
	 * @param string $key License key.
	 * @return true|WP_Error
	 */
	public static function activate( $key ) {
		$key = trim( sanitize_text_field( (string) $key ) );
		if ( '' === $key ) {
			return new WP_Error( 'gatehouse_pro_empty', __( 'Enter your license key.', 'gatehouse-pro' ) );
		}
		if ( ! self::store_configured() ) {
			return new WP_Error( 'gatehouse_pro_store', __( 'This copy of Gatehouse Pro is not connected to a store, so licenses cannot be activated.', 'gatehouse-pro' ) );
		}

		$data = self::request(
			'activate',
			array(
				'license_key'   => $key,
				'instance_name' => self::instance_name(),
			)
		);
		if ( is_wp_error( $data ) ) {
			return $data;
		}
		if ( empty( $data['activated'] ) || empty( $data['instance']['id'] ) ) {
			return new WP_Error( 'gatehouse_pro_activate', ! empty( $data['error'] ) ? (string) $data['error'] : __( 'The license could not be activated.', 'gatehouse-pro' ) );
		}
		if ( ! self::matches_product( $data ) ) {
			// Release the activation we just used on another product's key.
			self::request(
				'deactivate',
				array(
					'license_key' => $key,
					'instance_id' => $data['instance']['id'],
				)
			);
			return new WP_Error( 'gatehouse_pro_product', __( 'This license key is for a different product.', 'gatehouse-pro' ) );
		}

		$status = (string) ( $data['license_key']['status'] ?? 'active' );
		self::save(
			array(
				'key'           => $key,
				'instance_id'   => (string) $data['instance']['id'],
				'status'        => $status,
				'product'       => (string) ( $data['meta']['product_name'] ?? '' ),
				'expires_at'    => $data['license_key']['expires_at'] ?? null,
				'checked_at'    => time(),
				'last_valid_at' => 'active' === $status ? time() : 0,
				'error'         => 'active' === $status ? '' : self::status_message( $status ),
			)
		);
		return 'active' === $status ? true : new WP_Error( 'gatehouse_pro_status', self::status_message( $status ) );
	}

	/**
	 * Re-validate the stored license (weekly cron, or "Check now").
	 *
	 * @return array New state.
	 */
	public static function check() {
		$state = self::state();
		if ( '' === $state['key'] ) {
			return $state;
		}

		$data = self::request(
			'validate',
			array(
				'license_key' => $state['key'],
				'instance_id' => $state['instance_id'],
			)
		);
		$state['checked_at'] = time();

		if ( is_wp_error( $data ) ) {
			// Server unreachable: keep the current status; the grace period in is_active() applies.
			$state['error'] = $data->get_error_message();
			self::save( $state );
			return $state;
		}

		$status = (string) ( $data['license_key']['status'] ?? 'invalid' );
		if ( ! empty( $data['valid'] ) && 'active' === $status && self::matches_product( $data ) ) {
			$state['status']        = 'active';
			$state['last_valid_at'] = time();
			$state['expires_at']    = $data['license_key']['expires_at'] ?? $state['expires_at'];
			$state['error']         = '';
		} else {
			$state['status'] = empty( $data['valid'] ) && 'active' === $status ? 'invalid' : $status;
			$state['error']  = ! empty( $data['error'] ) ? (string) $data['error'] : self::status_message( $state['status'] );
		}
		self::save( $state );
		return $state;
	}

	/**
	 * Release this site's activation and forget the key.
	 */
	public static function deactivate() {
		$state = self::state();
		if ( '' !== $state['key'] && '' !== $state['instance_id'] ) {
			self::request(
				'deactivate',
				array(
					'license_key' => $state['key'],
					'instance_id' => $state['instance_id'],
				)
			);
		}
		delete_option( self::OPTION );
	}

	/**
	 * State safe to show in the dashboard (key masked).
	 *
	 * @return array
	 */
	public static function public_state() {
		$state = self::state();
		$key   = $state['key'];
		return array(
			'active'           => self::is_active(),
			'status'           => $state['status'],
			'key'              => '' === $key ? '' : str_repeat( '•', 8 ) . substr( $key, -4 ),
			'product'          => $state['product'],
			'expires_at'       => $state['expires_at'],
			'checked_at'       => $state['checked_at'] ? gmdate( 'c', (int) $state['checked_at'] ) : null,
			'error'            => $state['error'],
			'grace'            => 'active' === $state['status'] && $state['error'] && self::is_active(),
			'store_configured' => self::store_configured(),
		);
	}

	/**
	 * Whether a response belongs to our store and product.
	 *
	 * @param array $data Response.
	 * @return bool
	 */
	private static function matches_product( array $data ) {
		$store   = (int) ( $data['meta']['store_id'] ?? 0 );
		$product = (int) ( $data['meta']['product_id'] ?? 0 );
		if ( $store !== (int) GATEHOUSE_PRO_STORE_ID ) {
			return false;
		}
		return 0 === (int) GATEHOUSE_PRO_PRODUCT_ID || $product === (int) GATEHOUSE_PRO_PRODUCT_ID;
	}

	/**
	 * Call the License API.
	 *
	 * @param string $action `activate`, `validate` or `deactivate`.
	 * @param array  $body   Form fields.
	 * @return array|WP_Error Decoded response.
	 */
	private static function request( $action, array $body ) {
		$response = wp_remote_post(
			self::API . $action,
			array(
				'timeout' => 15,
				'headers' => array( 'Accept' => 'application/json' ),
				'body'    => $body,
			)
		);
		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'gatehouse_pro_network', __( 'Could not reach the licensing server. Try again in a few minutes.', 'gatehouse-pro' ) );
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $data ) || $code >= 500 ) {
			return new WP_Error( 'gatehouse_pro_network', __( 'The licensing server returned an unexpected response. Try again in a few minutes.', 'gatehouse-pro' ) );
		}
		return $data;
	}

	/**
	 * Readable message for a license status.
	 *
	 * @param string $status Status.
	 * @return string
	 */
	private static function status_message( $status ) {
		switch ( $status ) {
			case 'expired':
				return __( 'This license has expired. Renew it to keep using Pro features.', 'gatehouse-pro' );
			case 'disabled':
				return __( 'This license has been disabled.', 'gatehouse-pro' );
			case 'inactive':
				return __( 'This license is not active on this site.', 'gatehouse-pro' );
			default:
				return __( 'This license is not valid.', 'gatehouse-pro' );
		}
	}

	/**
	 * Name shown for this activation in the store dashboard.
	 *
	 * @return string
	 */
	private static function instance_name() {
		$host = wp_parse_url( home_url(), PHP_URL_HOST );
		return $host ? $host : home_url();
	}

	/**
	 * Save state.
	 *
	 * @param array $state State.
	 */
	private static function save( array $state ) {
		update_option( self::OPTION, $state, false );
	}
}
