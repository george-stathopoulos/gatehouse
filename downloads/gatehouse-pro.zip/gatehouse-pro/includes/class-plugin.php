<?php
/**
 * Pro bootstrap.
 *
 * @package Gatehouse_Pro
 */

defined( 'ABSPATH' ) || exit;

/**
 * Wires Gatehouse Pro into Gatehouse.
 */
final class Gatehouse_Pro_Plugin {

	/**
	 * Start once all plugins are loaded, if Gatehouse is active.
	 */
	public static function boot() {
		if ( ! class_exists( 'Gatehouse_Plugin' ) ) {
			add_action( 'admin_notices', array( __CLASS__, 'missing_notice' ) );
			return;
		}

		Gatehouse_Pro_Cache::init();
		Gatehouse_Pro_Updater::init();

		add_filter( 'gatehouse_pro_active', '__return_true' );
		add_action( 'rest_api_init', array( 'Gatehouse_Pro_REST', 'register' ) );
		add_action( 'gatehouse_admin_enqueue', array( __CLASS__, 'assets' ) );
		add_action( Gatehouse_Pro_License::CRON, array( 'Gatehouse_Pro_License', 'check' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( GATEHOUSE_PRO_FILE ), array( __CLASS__, 'action_links' ) );
	}

	/**
	 * Activation: create the cache table and schedule maintenance.
	 */
	public static function activate() {
		Gatehouse_Pro_Cache::install();
		if ( ! wp_next_scheduled( Gatehouse_Pro_Cache::PRUNE ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', Gatehouse_Pro_Cache::PRUNE );
		}
		if ( ! wp_next_scheduled( Gatehouse_Pro_License::CRON ) ) {
			wp_schedule_event( time() + DAY_IN_SECONDS, 'weekly', Gatehouse_Pro_License::CRON );
		}
	}

	/**
	 * Deactivation: stop scheduled work. The license and cache are kept.
	 */
	public static function deactivate() {
		wp_clear_scheduled_hook( Gatehouse_Pro_Cache::PRUNE );
		wp_clear_scheduled_hook( Gatehouse_Pro_License::CRON );
	}

	/**
	 * Load the Pro dashboard page into Gatehouse.
	 *
	 * @param string $handle Gatehouse's script handle.
	 */
	public static function assets( $handle ) {
		$asset_file = GATEHOUSE_PRO_DIR . 'build/index.asset.php';
		if ( ! file_exists( $asset_file ) ) {
			return;
		}
		$asset = require $asset_file;
		wp_enqueue_script( 'gatehouse-pro-admin', GATEHOUSE_PRO_URL . 'build/index.js', array_merge( $asset['dependencies'], array( $handle ) ), $asset['version'], true );
		wp_set_script_translations( 'gatehouse-pro-admin', 'gatehouse-pro' );
	}

	/**
	 * "Caching" and "License" links on the Plugins screen.
	 *
	 * @param string[] $links Links.
	 * @return string[]
	 */
	public static function action_links( $links ) {
		$url = admin_url( 'admin.php?page=gatehouse#/caching' );
		array_unshift( $links, '<a href="' . esc_url( $url ) . '">' . esc_html( Gatehouse_Pro_License::is_active() ? __( 'Caching', 'gatehouse-pro' ) : __( 'Activate license', 'gatehouse-pro' ) ) . '</a>' );
		return $links;
	}

	/**
	 * Notice when Gatehouse itself is missing.
	 */
	public static function missing_notice() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}
		echo '<div class="notice notice-warning"><p>' . esc_html__( 'Gatehouse Pro needs the free Gatehouse plugin. Install and activate Gatehouse to use Pro features.', 'gatehouse-pro' ) . '</p></div>';
	}
}
